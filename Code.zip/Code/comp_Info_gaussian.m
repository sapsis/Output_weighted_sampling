function [var1,Ver1] = comp_Info_gaussian(NN,aa,Cxx,sgmv,sgm2)

%%

var0=sum(aa.^2.*sgm2);

th0=0:0.01:pi;
dx=0.04;


%%

N_MC=10000;

N0=3;

for i=1:N0
XX(:,i)=mvnrnd([0,0],Cxx);

xx=XX(:,i);
yy=sum(aa.*xx')+sqrt(sgmv)*randn;
YY(i)=yy;
end


%% Entropy transfer 
XX1=XX;
YY1=YY;
Sxx=XX1*XX1';
Syx=YY1*XX1';
aa_es=Syx*Sxx^-1;


XX_M=mvnrnd([0,0],Cxx,N_MC);

for j=1:NN
        
          Sxx=XX1*XX1';
          Syx=YY1*XX1';
          aa_es=Syx*Sxx^-1;

    for m1=1:length(th0)
        
          hh=[cos(th0(m1));sin(th0(m1))];
          XX1t=[XX1,hh];
          Sxxt=XX1t*XX1t';          
          
          TT=Sxxt^-1*XX_M';
          cc=sum(XX_M'.*TT);
                      
          QQ(m1)=-mean(log(1+cc));
     end
  
  %figure(2); 
% 
% subplot(1,2,1);   plot(th0,QQ,'r'); hold on; plot(th0,Entr1,'b'); hold off;
% subplot(1,2,2);   plot(th0,QQ,'r'); hold on; plot(th0,Entr2,'b'); hold off;
% 
%     pause(1);
  %pcolor(H0,H0,QQ); shading interp;
  %pause(1)
  [minQQ,I] = max(QQ);
          
        XX1(:,j+N0)=[cos(th0(I));sin(th0(I))];
        xx=XX1(:,j+N0);
        yy=aa(1)*xx(1)+aa(2)*xx(2)+sqrt(sgmv)*randn;
        YY1(j+N0)=yy;

Sxx=XX1*XX1';
Syx=YY1*XX1';
aa_es=Syx*Sxx^-1;

var1(j)=abs(sum(aa_es.^2.*sgm2)-var0); 

end

Ver1=XX1(:,N0+1:end);
% end
% 

% figure(1); hold on;
% plot(var3,'g');
% figure(3);
% subplot(1,2,1); ksdensity(Ver);
% subplot(1,2,2); plot(Ver,'g+')

