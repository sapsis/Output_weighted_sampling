function [ww] = coef_determ(aa,sigma)

% Function to identify p1 and p2
%aa=3; % how many sigmas we want to optimally approximate the inverse Gaussian

xx=linspace(0,aa*sigma,100000);

fx=sqrt(2*pi*sigma^2)*exp(xx.^2/2/sigma^2); % inverse of the Gaussian;

zz=linspace(0,aa,100000);
fn=sqrt(2*pi)*exp(zz.^2/2); % inverse of the Gaussian;


% AA=[aa,aa^3/3;aa^3/3,aa^5/5];
% FF=[sum(fx)*(xx(2)-xx(1));sum(fx.*xx.^2)*(xx(2)-xx(1))];
% 
% p=AA^-1*FF;
% plot(xx,p(1)+p(2)*xx.^2,'c');

p(2)=5/aa^5/sigma*(sum(fn.*zz.^2)*(zz(2)-zz(1))-sqrt(2*pi)*aa^3/3);
p(1)=sqrt(2*pi)*sigma;

ww=p(1)/p(2);

% plot(xx,fx,'r-'); hold on;
% plot(xx,p(1)+p(2)*xx.^2,'g');
% 



%%
% clear all
% aas=0.01:0.01:4;
% sigma=1;
% 
% for k=1:length(aas)
%     aa=aas(k);
%     zz=linspace(0,aa,10000);
% fn=sqrt(2*pi)*exp(zz.^2/2); % inverse of the Gaussian;
% 
% p(k)=5/aa^5/sigma*(sum(fn.*zz.^2)*(zz(2)-zz(1))-sqrt(2*pi)*aa^3/3);
% end
% 
% plot(aas,p)
% 
