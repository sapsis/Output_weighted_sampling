function [c,ceq] = unitdisk(x)
c = [ ];
ceq = norm(x)^2 - 1;