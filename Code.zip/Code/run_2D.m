clear all;
close all;
%parpool;

% Case I parameters 
aa=[0.8,1.3];
sgm2=[1.4,0.6];

% Case II parameters
% aa=[0.01,2.0];
% sgm2=[2.0,0.2];
% 

flg=1; % set this to 1  if we want to do any dimension with minimization through gradient 
        % Set this to 0 if we want to do minimization over a discrete grid (only for 2D inputs)


sgmv=0.05;
Cxx=diag(sgm2);
NN=300;

for k=1:400
    k
[var1,Ver1]=comp_MC(NN,aa,Cxx,sgmv,sgm2);

VV1(k,:)=var1;

[var2,Ver2]=comp_mu(NN,aa,Cxx,sgmv,sgm2,flg);

VV2(k,:)=var2;

[var3,Ver3]=comp_Q(NN,aa,Cxx,sgmv,sgm2,flg);

VV3(k,:)=var3;

VVp2(k,:)=atan(Ver2(2,:)./Ver2(1,:));
VVp3(k,:)=atan(Ver3(2,:)./Ver3(1,:));

end

v1=mean(VV1); v1s=std(VV1);
v2=mean(VV2); v2s=std(VV2);
v3=mean(VV3); v3s=std(VV3);

% plot(v1+0.5*v1s,'b--'); plot(v1-0.5*v1s,'b--')
%%
figure;
semilogy(v1,'b','linewidth',2); hold on; semilogy(v2,'r','linewidth',2); semilogy(v3,'g','linewidth',2); 

sds=0.2;
inBetween = [v1+sds*v1s, fliplr(v1-sds*v1s)];
x2 = [[1:NN], fliplr([1:NN])];
fill(x2, inBetween, 'b','LineStyle','none');alpha(0.25); hold on;

inBetween = [v2+sds*v2s, fliplr(v2-sds*v2s)];
x2 = [[1:NN], fliplr([1:NN])];
fill(x2, inBetween, 'r','LineStyle','none');alpha(0.15)

inBetween = [v3+sds*v3s, fliplr(v3-sds*v3s)];
x2 = [[1:NN], fliplr([1:NN])];
fill(x2, inBetween, 'g','LineStyle','none');alpha(0.15)

legend('Monte-Carlo','$\mu_c(\mathbf{h})$','$Q(\mathbf{h})$','Interpreter','latex')
xlabel('$N$','Interpreter','latex'); ylabel('$|\sigma^2(y|{D_N})-\sigma^2(y)|$','Interpreter','latex')

figure;
ksdensity(VVp2(:),[-3.15/2:0.01:3.16/2],'Support',[-3.15/2 3.15/2],'BoundaryCorrection','reflection'); hold on;
ksdensity(VVp3(:),[-3.15/2:0.01:3.15/2],'Support',[-3.15/2 3.15/2],'BoundaryCorrection','reflection')

legend('$\mu_c(\mathbf{h})$','$Q(\mathbf{h})$','Interpreter','latex')
ylabel({'$f(\theta)$'},'Interpreter','latex');
xlabel({'$\theta=arctan(h_2/h_1)$'},'Interpreter','latex');
ax=gca;
set(ax,'FontSize',24,...
    'TickLabelInterpreter','latex','XTick',[-1.57 -0.785 0 0.785 1.57],...
    'XTickLabel',{'$-\pi/2$','$-\pi/4$','0','$\pi/4$','$\pi/2$'});


% 

save('run10.mat')
