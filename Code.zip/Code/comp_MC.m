function [var1,Ver1] = comp_MC(NN,aa,Cxx,sgmv,sgm2)

%%

var0=sum(aa.^2.*sgm2);

%%

% N0=3;
% 
% for i=1:N0
% XX(:,i)=mvnrnd(zeros(1,size(Cxx,1)),Cxx);
% 
% xx=XX(:,i);
% yy=sum(aa.*xx')+sqrt(sgmv)*randn;
% YY(i)=yy;
% end
% 
for i=1:size(Cxx,1)
XX(:,i)=zeros(size(Cxx,1),1);
XX(i,i)=1;
xx=XX(:,i);
yy=sum(aa.*xx')+sqrt(sgmv)*randn;
YY(i)=yy;
end
N0=size(Cxx,1);


%% Monte Carlo
XX1=XX;
YY1=YY;

for j=1:NN

    
xxtemp=mvnrnd(zeros(1,size(Cxx,1)),Cxx);
xxtemp=xxtemp/norm(xxtemp);
XX1(:,j+N0)=xxtemp;

xx=XX1(:,j+N0);
yy=sum(aa.*xx')+sqrt(sgmv)*randn;
YY1(j+N0)=yy;


Sxx=XX1*XX1';
Syx=YY1*XX1';

aa_es=Syx*Sxx^-1;

var1(j)=abs(sum(aa_es.^2.*sgm2)-var0);

end

Ver1=XX1(N0+1:end);

