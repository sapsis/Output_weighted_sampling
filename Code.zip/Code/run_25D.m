clear all;
close all;
rng(10);
%parpool;
for j=1:20
aa(j)=(0.01+0.1*j^3/250)/10;
sgm2(j)=(0.8+(j-10)^2/40)/32;
end
% plot(aa,'+');hold on; plot(sgm2,'o')

flg=1; % set this to 1  if we want to do any dimension with minimization through gradient 
        % Set this to 0 if we want to do minimization over a discrete grid (only for 2D inputs)

sgmv=0.05;
Cxx=diag(sgm2);
NN=400;

for k=1:400
    k
[var1,Ver1]=comp_MC(NN,aa,Cxx,sgmv,sgm2);

VV1(k,:)=var1;

[var2,Ver2]=comp_mu(NN,aa,Cxx,sgmv,sgm2,flg);

VV2(k,:)=var2;

[var3,Ver3]=comp_Qs(NN,aa,Cxx,sgmv,sgm2,flg,alpha0);

VV3(k,:)=var3;

VVp2(k,:,:)=Ver2(:,:);
VVp3(k,:,:)=Ver3(:,:);

end


v1=mean(VV1); v1s=std(VV1);
v2=mean(VV2); v2s=std(VV2);
v3=mean(VV3); v3s=std(VV3);

save('run_HighD_CaseI.mat')

