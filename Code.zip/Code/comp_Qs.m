function [var1,Ver1] = comp_Q(NN,aa,Cxx,sgmv,sgm2,flg,alpha0)

%% Computation based on the Q criterion

var0=sum(aa.^2.*sgm2);

%%

% N0=4; % Initial points
% 
% for i=1:N0
% XX(:,i)=mvnrnd(zeros(1,size(Cxx,1)),Cxx);
% xx=XX(:,i);
% yy=sum(aa.*xx')+sqrt(sgmv)*randn;
% YY(i)=yy;
% end


for i=1:size(Cxx,1)
XX(:,i)=zeros(size(Cxx,1),1);
XX(i,i)=1;
xx=XX(:,i);
yy=sum(aa.*xx')+sqrt(sgmv)*randn;
YY(i)=yy;
end
N0=size(Cxx,1);


%% Q
XX1=XX;
YY1=YY;
Sxx=XX1*XX1';
Syx=YY1*XX1';
aa_es=Syx*Sxx^-1;
vart=sum(aa_es.^2.*sgm2);

if flg==1

    for j=1:NN

    A = []; b = []; Aeq = []; beq = []; lb = []; ub = [];
    nonlcon = @unitdisk;
    x0 = mvnrnd(zeros(1,size(Cxx,1)),eye(size(Cxx,1))); 
 %   x0 = mvnrnd(zeros(1,size(Cxx,1)),Cxx);   
    x0 = x0/norm(x0);

    % this is used in remark **
%     ww(1)=alpha0; ww(2)=0.5-alpha0;
%     f_sp = @(h)sp_fun1(h,Sxx,ww(1)*Cxx+2*ww(2)*Cxx*Sxx^-1*Syx'*Syx*Sxx^-1*Cxx);

f_sp = @(h)sp_fun1(h,Sxx,alpha0*vart*Cxx+2*Cxx*Sxx^-1*Syx'*Syx*Sxx^-1*Cxx);
    options = optimoptions('fmincon','SpecifyObjectiveGradient',true,'Display','off');
    xa = fmincon(f_sp,x0',A,b,Aeq,beq,lb,ub,nonlcon,options);


    XX1(:,j+N0)=xa;
    yy=sum(aa.*xa')+sqrt(sgmv)*randn; 
    YY1(j+N0)=yy;

    Sxx=XX1*XX1';
    Syx=YY1*XX1';

    aa_es=Syx*Sxx^-1;
    vart=sum(aa_es.^2.*sgm2);
    var1(j)=abs(vart-var0); 

    end

else
    for j=1:NN
    th0=0:0.01:pi;
    
    for m1=1:length(th0)
        
          hh=[cos(th0(m1));sin(th0(m1))];
          XX1t=[XX1,hh];
          Sxxt=XX1t*XX1t';
          Sxx=XX1*XX1';
          Syx=YY1*XX1';

          QQ(m1)=trace(Syx*Sxx^-1*Cxx*Sxxt^-1*Cxx*Sxx^-1*Syx');
          
    end
  
    [minQQ,I] = min(QQ);
    
    xa=[cos(th0(I));sin(th0(I))];
    XX1(:,j+N0)=xa;
    yy=sum(aa.*xa')+sqrt(sgmv)*randn; 
    YY1(j+N0)=yy;

    Sxx=XX1*XX1';
    Syx=YY1*XX1';

    aa_es=Syx*Sxx^-1;

    var1(j)=abs(sum(aa_es.^2.*sgm2)-var0); 
    end
end

Ver1=XX1(:,N0+1:end);