function [f,g] = sp_fun1(h,SS,CC)

SSn=SS+h*h';
SSni=SSn^-1;
f=trace(SSni*CC);
g=-2*h'*SSni*CC*SSni;